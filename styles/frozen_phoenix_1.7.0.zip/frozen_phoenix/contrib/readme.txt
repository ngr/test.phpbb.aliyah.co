===============================================================================

Style name: Frozen Phoenix
Style Version: 1.7.0
Created by: Mighty Gorgon < http://www.icyphoenix.com >
Copyright 2012 Mighty Gorgon < http://www.icyphoenix.com >
Some icons are courtesy of http://www.famfamfam.com/lab/icons/silk/

===============================================================================

Installation:
Upload the frozen_phoenix folder into your styles directory and then install it
from ACP.

===============================================================================

You can modify this theme anyway you want as long as my copyright and links
remain in the footer.

You cannot redistribute this theme in whole or in part without my permission.

Custom edits, graphics and changes available at http://www.icyphoenix.com

New styles section:
http://www.icyphoenix.com/styles/styles.php?cat_id=phpbb3

You can customize template colors from this link:
http://www.icyphoenix.com/styles/colorizeit.php

===============================================================================

Theme History

* 2013/10/01 - Version 1.7.0
- Style updated to phpBB 3.0.12
	# search_results.html

* 2012/09/01 - Version 1.6.9
- Style updated to phpBB 3.0.11
	# editor.js
	# stylesheet.css
	# captcha_default.html
	# captcha_qa.html
	# faq_body.html
	# login_body.html
	# mcp_topic.html
	# overall_footer.html
	# posting_body.html
	# posting_buttons.html
	# simple_footer.html
	# ucp_header.html
	# ucp_profile_reg_details.html

* 2012/01/06 - Version 1.6.8
- Style updated to phpBB 3.0.10
	# overall_header.html
	# viewtopic_body.html

* 2011/07/31 - Version 1.6.7
- Some files updated just to fix some typos and minor things
	# overall_header.html
	# simple_header.html

* 2011/07/11 - Version 1.6.5
- Style updated to phpBB 3.0.9
- Files updated:
	# style.cfg
	# imageset.cfg
	# template.cfg
	# theme.cfg
	# colours.css
	# cp.css
	# forms.css
	# links.css
	# print.css
	# tweaks.css
	# overall_footer.html
	# overall_header.html
	# simple_header.html
	# viewforum_body.html
	# viewtopic_body.html

* 2011/02/11 - Version 1.6.4
- Minor fixes
- License

* 2010/11/21 - Version 1.6.3
- Style updated to phpBB 3.0.8
- Files updated:
	# editor.js
	# breadcrumbs_main.html
	# overall_header.html
	# posting_topic_review.html
	# simple_header.html
	# viewforum_body.html

* 2010/04/30 - Version 1.6.2
- Files updated:
	# breadcrumbs_main.html

* 2010/03/01 - Version 1.6.1
- Style updated to phpBB 3.0.7
- Files updated:
	# style.cfg
	# imageset.cfg
	# template.cfg
	# theme.cfg
	# editor.js
	# index_body.html
	# overall_header.html
	# search_results.html
	# viewforum_body.html

* 2009/11/21 - Version 1.6.0
- Style updated to phpBB 3.0.6

* 2009/09/15 - Version 1.0.0
- First unofficial release

===============================================================================
